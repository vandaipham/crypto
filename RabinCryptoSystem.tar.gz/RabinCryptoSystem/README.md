RabinCryptoSystem
=================
Implementation of the Rabin cryptosystem in C++ .
